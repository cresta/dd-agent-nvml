# (C) Datadog, Inc. 2020-present
# All rights reserved
# Licensed under a 3-clause BSD style license (see LICENSE)
# flake8: noqa E501

import os.path
import time

import grpc
import pynvml

from datadog_checks.base import AgentCheck

from .build import api_pb2_grpc

METRIC_PREFIX = "nvml."
SOCKET_PATH = "/var/lib/kubelet/device-plugins/kubelet.sock"


class KubTagger:
    def __init__(self, log):
        self.known_tags = {}
        self.log = log
        if not os.path.exists(SOCKET_PATH):
            return
        self.d = threading.Thread(target=self.refresh_loop, name='k8s-tag-refresh-loop', daemon=True)

    def refresh_loop(self):
        while True:
            self.refresh_tags()
            time.sleep(10)

    def refresh_tags(self):
        channel = grpc.insecure_channel('unix:/' + SOCKET_PATH)
        stub = api_pb2_grpc.PodResourcesListerStub(channel)
        log.info("Refreshing tags")
        res = stub.List()
        log.info(dir(res))

    def get_tags(self, device_id):
        return self.known_tags.get(device_id, [])


class NvmlCheck(AgentCheck):
    N = pynvml

    class NvmlInit(object):
        def __enter__(self):
            NvmlCheck.N.nvmlInit()

        def __exit__(self, exception_type, exception_value, traceback):
            NvmlCheck.N.nvmlShutdown()

    def __init__(self, *args, **kwargs):
        self.k8s_tagger = None
        super(NvmlCheck, self).__init__(*args, **kwargs)

    def check(self, instance):
        if self.k8s_tagger is None:
            self.k8s_tagger = KubTagger(self.log)
        with NvmlCheck.NvmlInit():
            self.gather(instance)

    def add_gauge(self, name, value, tags=None):
        if tags is None:
            tags = []
        self.gauge(METRIC_PREFIX + name, value, tags)

    def gather_gpu(self, instance, gpu_idx):
        handle = NvmlCheck.N.nvmlDeviceGetHandleByIndex(gpu_idx)
        uuid = NvmlCheck.N.nvmlDeviceGetUUID(handle)
        tags = ["gpu:" + str(gpu_idx), "uuid:%s" % uuid.decode("utf-8")]
        tags += self.k8s_tagger.get_tags(uuid)
        # Utilization information for a device. Each sample period may be between 1 second and 1/6 second, depending on the product being queried.
        # Taking names to match https://github.com/NVIDIA/gpu-monitoring-tools/blob/master/exporters/prometheus-dcgm/dcgm-exporter/dcgm-exporter
        # Documented at https://docs.nvidia.com/deploy/nvml-api/group__nvmlDeviceQueries.html
        util = NvmlCheck.N.nvmlDeviceGetUtilizationRates(handle)
        self.add_gauge('gpu_utilization', util.gpu, tags=tags)
        self.add_gauge('mem_copy_utilization', util.memory, tags=tags)

    def gather(self, instance):
        deviceCount = NvmlCheck.N.nvmlDeviceGetCount()
        for i in range(deviceCount):
            self.gather_gpu(instance, i)
